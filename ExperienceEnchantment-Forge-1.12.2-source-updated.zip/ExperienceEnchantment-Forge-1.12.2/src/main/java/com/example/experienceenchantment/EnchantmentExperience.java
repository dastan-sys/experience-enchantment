package com.example.experienceenchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;

public class EnchantmentExperience extends Enchantment {
    public EnchantmentExperience() {
        super(Rarity.RARE, EnumEnchantmentType.BREAKABLE, new EntityEquipmentSlot[] {
            EntityEquipmentSlot.MAINHAND
        });
    }

    @Override
    public int getMinLevel() {
        return 1;
    }

    @Override
    public int getMaxLevel() {
        return 10;
    }

    @Override
    public int getMinEnchantability(int level) {
        return 10 + (level - 1) * 8;
    }

    @Override
    public int getMaxEnchantability(int level) {
        return getMinEnchantability(level) + 25;
    }

    @Override
    public boolean isTreasureEnchantment() {
        return false;
    }

    @Override
    public boolean canApply(ItemStack stack) {
        return super.canApply(stack) && stack.isItemStackDamageable();
    }

    public static int getMultiplier(int level) {
        if (level <= 0) return 1;
        return 1 << Math.min(level, 15); // I=x2, II=x4, III=x8 ... X=x1024
    }
}
