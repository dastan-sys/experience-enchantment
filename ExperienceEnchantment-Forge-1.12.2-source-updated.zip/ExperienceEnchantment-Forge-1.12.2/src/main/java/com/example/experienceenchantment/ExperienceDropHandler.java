package com.example.experienceenchantment;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Adds XP directly to the player to avoid spawning many XP-orb entities. */
public class ExperienceDropHandler {

    @SubscribeEvent
    public void onMobExperienceDrop(LivingExperienceDropEvent event) {
        if (event.getEntityLiving().world.isRemote) return;

        EntityPlayer player = event.getAttackingPlayer();
        if (player == null) return;

        int level = getLevel(player.getHeldItemMainhand());
        if (level <= 0) return;

        int original = event.getDroppedExperience();
        if (original <= 0) return;

        int multiplier = EnchantmentExperience.getMultiplier(level);
        long total = (long) original * multiplier;
        event.setDroppedExperience(0);
        player.addExperience((int) Math.min(total, 32767L));
    }

    @SubscribeEvent
    public void onBlockBroken(BlockEvent.BreakEvent event) {
        EntityPlayer player = event.getPlayer();
        World world = player.world;
        if (world.isRemote) return;

        int level = getLevel(player.getHeldItemMainhand());
        if (level <= 0) return;

        int originalXp = event.getExpToDrop();
        if (originalXp <= 0) return;

        int multiplier = EnchantmentExperience.getMultiplier(level);
        long total = (long) originalXp * multiplier;
        event.setExpToDrop(0);
        player.addExperience((int) Math.min(total, 32767L));
    }

    private int getLevel(ItemStack stack) {
        if (stack.isEmpty() || ExperienceEnchantmentMod.EXPERIENCE == null) return 0;
        return net.minecraft.enchantment.EnchantmentHelper.getEnchantmentLevel(
            ExperienceEnchantmentMod.EXPERIENCE, stack
        );
    }
}
