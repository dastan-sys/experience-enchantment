package com.example.experienceenchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraft.util.ResourceLocation;

@Mod(
    modid = ExperienceEnchantmentMod.MODID,
    name = ExperienceEnchantmentMod.NAME,
    version = ExperienceEnchantmentMod.VERSION,
    acceptedMinecraftVersions = "[1.12.2]"
)
@Mod.EventBusSubscriber
public class ExperienceEnchantmentMod {
    public static final String MODID = "experienceenchantment";
    public static final String NAME = "Experience Enchantment";
    public static final String VERSION = "1.0.0";

    public static Enchantment EXPERIENCE;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new ExperienceDropHandler());
    }

    @SubscribeEvent
    public static void registerEnchantments(RegistryEvent.Register<Enchantment> event) {
        EXPERIENCE = new EnchantmentExperience();
        EXPERIENCE.setRegistryName(new ResourceLocation(MODID, "experience"));
        EXPERIENCE.setName("experienceenchantment.experience");
        event.getRegistry().register(EXPERIENCE);
    }
}
